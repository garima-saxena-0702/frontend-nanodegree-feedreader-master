# Feed Reader Testing
===============================

Testing is an important part of the development process and many organizations practice a standard of development known as "test-driven development". This project is a web-based application that reads RSS feeds. Here, an open source behavior-driven javascript development framework "Jasmine" is used for testing.

# Reference
===============================
Jasmine :- (https://jasmine.github.io/)


# Usage
===============================

Right click on index.html file and open it with browser. The Window screen will show the spec run and any error or failure cases.


Browser Support
===============================

This game supports google chrowe, mozilla firefox and safari.